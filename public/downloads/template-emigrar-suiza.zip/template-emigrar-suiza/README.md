# 🇨🇭 Template Notion: Checklist Completa Emigrar a Suiza

## 📦 Contenido del Template

Este template incluye TODO lo que necesitas para emigrar a Suiza de forma organizada:

### ✅ 1. Checklist 50 Pasos
Base de datos completa con todos los pasos necesarios organizados por:
- **Fase**: Antes de partir / Primeros 14 días / Primeros 30 días / Primeros 90 días / Optimización
- **Categoría**: Documentos / Finanzas / Trámites / Logística / Setup vida
- **Prioridad**: Crítica / Alta / Media / Baja
- **Estado**: Pendiente / En progreso / Completado

### 📄 2. Base de Datos Documentos
30 documentos importantes pre-cargados:
- Oficiales (pasaporte, permiso, DNI)
- Trabajo (contrato, AVS, nóminas)
- Vivienda (alquiler, depósito)
- Finanzas (banco, Pillar 3a)
- Seguros (médico, responsabilidad civil, coche)
- Con campos: Estado, Vencimiento, Dónde guardado, Notas

### 👥 3. Base de Datos Contactos Útiles
50+ contactos pre-cargados:
- Oficinas oficiales (migración, comuna, consulados)
- Seguros médicos (5 principales con comparativa)
- Bancos (tradicionales + neobanks)
- Servicios (transporte, telecomunicaciones, vivienda, empleo)
- Comunidad expats
- Emergencias

### 💰 4. Tracker Gastos Primer Año
Sistema completo de seguimiento financiero:
- Categorías pre-configuradas
- Presupuesto tipo por categoría
- Campo "Deducible impuestos"
- Métricas automáticas

### 📚 5. 7 Guías Paso a Paso
Guías completas (100-300 líneas cada una):
1. **Registro en la Comuna (Anmeldung)** - CRÍTICO 14 días
2. **Elegir Seguro Médico** - Comparativa + ahorro CHF 2'000/año
3. **Abrir Cuenta Bancaria** - Neon vs PostFinance vs tradicionales
4. **Homologar Carnet Conducir** - Proceso por cantón
5. **Buscar Piso** - Portales + estrategia ganar candidatura
6. **Impuestos Suiza Básico** - Pillar 3a + deducciones
7. **Ahorrar Dinero** - Trucos ahorrar CHF 15'000/año

### 📝 6. Plantillas Documentos
- Email solicitud piso (alemán + francés)
- CV formato suizo
- Carta presentación

---

## 🚀 Cómo Usar Este Template

### Paso 1: Importar a Notion
1. Abre Notion.so
2. Crea nueva página "Mi Emigración a Suiza"
3. Importa los archivos CSV:
   - `databases/01-checklist-50-pasos.csv`
   - `databases/02-documentos.csv`
   - `databases/03-contactos-utiles.csv`
   - `databases/04-tracker-gastos.csv`

### Paso 2: Configurar Vistas
En cada base de datos crea vistas:
- **Kanban**: Por estado (Pendiente → En progreso → Completado)
- **Calendario**: Por fecha vencimiento
- **Tabla**: Vista completa
- **Filtros**: Por prioridad, por categoría

### Paso 3: Vincular Guías
- Copia el contenido de `guias/*.md`
- Crea sub-páginas en Notion
- Vincula desde checklist (ej: paso "Registro comuna" → link guía completa)

### Paso 4: Personalizar
- Actualiza fechas según tu llegada
- Marca pasos ya completados
- Añade notas personales
- Adjunta documentos escaneados

---

## 📊 Estructura Archivos

```
template-emigrar-suiza/
├── databases/
│   ├── 01-checklist-50-pasos.csv (50 tareas organizadas)
│   ├── 02-documentos.csv (30 documentos importantes)
│   ├── 03-contactos-utiles.csv (50+ contactos útiles)
│   └── 04-tracker-gastos.csv (Presupuesto + tracker)
├── guias/
│   ├── 01-registro-comuna-anmeldung.md
│   ├── 02-elegir-seguro-medico.md
│   ├── 03-abrir-cuenta-bancaria.md
│   ├── 04-homologar-carnet-conducir.md
│   ├── 05-buscar-piso.md
│   ├── 06-impuestos-suiza-basico.md
│   └── 07-ahorrar-dinero-suiza.md
├── plantillas/
│   ├── email-solicitud-piso-aleman.txt
│   ├── email-solicitud-piso-frances.txt
│   └── cv-formato-suizo.txt
└── README.md (este archivo)
```

---

## 💡 Ventajas de Este Template

### ✅ Completitud
- 50 pasos: NO te olvidas nada crítico
- 7 guías profundas: Información que normalmente cuesta CHF 200-500 en asesoría
- Contactos verificados: Números/URLs actualizados 2026

### ✅ Ahorro Económico
Siguiendo las guías ahorras:
- CHF 2'000/año seguro médico (eligiendo bien)
- CHF 15'000/año gastos vida (trucos ahorro)
- CHF 500 evitar multas (registro a tiempo, homologación)

### ✅ Ahorro Tiempo
- Sin buscar información dispersa
- Todo en un solo lugar
- Directamente accionable

### ✅ Reducción Estrés
- Checklist clara → tranquilidad mental
- Deadlines visibles → no sorpresas
- Progreso medible → motivación

---

## 🎯 Timeline Uso Recomendado

### 3 meses antes de partir
- [ ] Revisar checklist completa
- [ ] Empezar documentos oficiales (apostillas)
- [ ] Leer todas las guías
- [ ] Preparar dosier piso

### 1 mes antes
- [ ] Buscar alojamiento temporal
- [ ] Abrir cuentas internacionales (Wise)
- [ ] Avisar empleador/universidad
- [ ] Cancelar contratos España

### Día 0 (llegada)
- [ ] Activar checklist "Primeros 14 días"
- [ ] Buscar piso definitivo (si temporal)

### Día 1-14
- [ ] **CRÍTICO**: Registro comuna
- [ ] Número móvil suizo
- [ ] Buscar médico cabecera (si modelo restrictivo)

### Día 15-30
- [ ] Solicitar permiso residencia
- [ ] Contratar seguro médico
- [ ] Abrir cuenta bancaria
- [ ] Firmar contrato alquiler definitivo

### Día 30-90
- [ ] Completar setup vida (muebles, servicios)
- [ ] Abrir Pillar 3a
- [ ] Homologar carnet (empezar proceso)

### Mes 6+
- [ ] Optimizar todo (cambiar seguro, buscar mejor móvil)
- [ ] Networking comunidad
- [ ] Explorar Suiza

---

## 📈 ROI Este Template

**Inversión:** CHF 19-39
**Ahorro primer año:** CHF 15'000-20'000 (siguiendo guías)
**Tiempo ahorrado:** 40-60 horas (investigación)
**Estrés evitado:** Invaluable

**ROI:** 500x-1'000x

---

## 🆘 Soporte

**Preguntas frecuentes:**
- Todas las guías tienen sección FAQ
- Contactos con teléfonos/URLs oficiales

**Actualizaciones:**
- Template actualizado enero 2026
- Información válida 2026
- Si compras versión Premium: actualizaciones anuales

---

## ⭐ Feedback

Si este template te ayudó:
- ✉️ Envía email: [tu email soporte]
- ⭐ Deja review en [plataforma venta]
- 💬 Comparte en grupos Facebook expats

---

## 📄 Licencia

**Uso personal:** Ilimitado
**Redistribución:** Prohibida
**Modificación:** Permitida para uso personal

---

**¡Éxito en tu aventura suiza! 🇨🇭**

*Creado por [Tu Nombre] - HispanosEnSuiza.ch*
*Actualizado: Enero 2026*
