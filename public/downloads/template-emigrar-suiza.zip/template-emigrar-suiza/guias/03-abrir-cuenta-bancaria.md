# 🏦 Guía: Abrir Cuenta Bancaria en Suiza

## 💳 ¿Por Qué Necesitas Cuenta Suiza?

**Obligatorio para:**
- Recibir nómina (empleador no paga a cuenta extranjera)
- Domiciliar seguro médico
- Pagar alquiler
- Usar TWINT (app pagos más usada)
- Depósito alquiler (cuenta bloqueada)

**Plazo recomendado:** Primera semana tras registro comuna

---

## 🏦 Tipos de Bancos

### 1. Bancos Tradicionales (Caros)
**UBS, Credit Suisse, Raiffeisen, PostFinance**

✅ Ventajas:
- Red oficinas física
- Cajeros propios sin comisión
- Servicios completos

❌ Desventajas:
- Mantenimiento: CHF 5-15/mes
- Comisiones altas
- Trámites lentos
- Requieren cita presencial

### 2. Neobanks (Recomendado)
**Neon, Yuh, Revolut Suiza**

✅ Ventajas:
- **Mantenimiento: CHF 0**
- Apertura 100% online
- App excelente
- Sin comisiones SEPA
- Aprobación en 24-48h

❌ Desventajas:
- Sin oficina física
- Atención solo digital
- Algunos servicios limitados

---

## 🏆 Top 5 Bancos Recomendados

### 1. **Neon** ⭐⭐⭐⭐⭐ (MÁS RECOMENDADO)
**Gratis, digital, perfecto para empezar**

- **Mantenimiento:** CHF 0
- **Tarjeta débito:** Gratis
- **Retiradas cajero:** 5 gratis/mes, luego CHF 2
- **TWINT:** Incluido
- **Apertura:** 100% online, 10 minutos
- **Requisitos:** Permiso residencia + móvil suizo
- **Web:** www.neon-free.ch

**Mejor para:** Recién llegados, uso diario, primera cuenta

### 2. **Yuh** ⭐⭐⭐⭐
**Gratis + inversión + cashback**

- **Mantenimiento:** CHF 0
- **Tarjeta:** Gratis (Mastercard)
- **Inversión:** Acciones/ETFs desde CHF 1
- **Cashback:** 0.5-1% compras
- **Asociación:** PostFinance + Swissquote
- **Web:** www.yuh.com

**Mejor para:** Quieres invertir + ahorrar

### 3. **PostFinance** ⭐⭐⭐⭐
**Semi-tradicional, sin comisiones**

- **Mantenimiento:** CHF 0 (cuenta e-finance)
- **Oficinas:** Todas las oficinas Correos
- **Cajeros:** Red más grande Suiza
- **TWINT:** Incluido
- **Requisitos:** Cita + documentos
- **Web:** www.postfinance.ch

**Mejor para:** Quieres oficina física pero sin pagar

### 4. **Revolut Suiza** ⭐⭐⭐⭐
**Internacional, multidivisa**

- **Mantenimiento:** CHF 0 (plan básico)
- **Multidivisa:** 30+ monedas
- **Cambio divisa:** Excelente
- **Transferencias:** Internacional barato
- **Requisitos:** Registro online
- **Web:** www.revolut.com/ch

**Mejor para:** Viajas mucho, familia en extranjero

### 5. **Raiffeisen** ⭐⭐⭐
**Tradicional cooperativo**

- **Mantenimiento:** CHF 5/mes
- **Oficinas:** Muchas en ciudades pequeñas
- **Hipotecas:** Mejores tasas
- **Requisitos:** Cita presencial
- **Web:** www.raiffeisen.ch

**Mejor para:** Largo plazo, comprar casa

---

## 📋 Documentos Necesarios

### Para Neon/Yuh (online):
1. Pasaporte o DNI (foto desde app)
2. Permiso residencia B/L (foto)
3. Certificado registro comuna
4. Número móvil suizo
5. Selfie verificación

### Para PostFinance/UBS/Credit Suisse (presencial):
1. Pasaporte/DNI original
2. Permiso residencia B/L original
3. Certificado registro comuna
4. Contrato trabajo
5. Justificante domicilio (contrato alquiler)
6. A veces: referencias laborales

---

## 🔄 Proceso Apertura (Neon - Recomendado)

### Paso 1: Descarga app
- iOS: App Store "Neon Banking"
- Android: Google Play "Neon Banking"

### Paso 2: Registro (5 min)
1. Email + contraseña
2. Número móvil suizo (verificación SMS)
3. Datos personales

### Paso 3: Verificación identidad (5 min)
1. Foto pasaporte/DNI
2. Foto permiso residencia
3. Selfie (anti-fraude)
4. Video llamada verificación (opcional, si falla automático)

### Paso 4: Aprobación
- **Normalmente:** 24-48 horas
- **Rápido:** Mismo día
- Recibes email confirmación

### Paso 5: Activación
- Tarjeta física llega en 5-7 días
- Puedes usar virtual inmediatamente (Apple Pay/Google Pay)
- Activas con código en app

**Tiempo total:** 10 min registro + 1-2 días aprobación

---

## 💡 TWINT - Imprescindible en Suiza

**¿Qué es TWINT?**
- App pagos móvil (como Bizum en España)
- Usar en 90% tiendas/restaurantes
- Enviar dinero a amigos
- Pagar parking/billetes tren

**¿Cómo conseguirlo?**
- Neon/Yuh: Integrado en app
- PostFinance/UBS: App separada TWINT
- **GRATIS** en todos los bancos

---

## 💰 Costes Comparativa

| Banco | Mantenimiento | Tarjeta | Retiradas | Transferencias |
|-------|---------------|---------|-----------|----------------|
| Neon | CHF 0 | CHF 0 | 5 gratis/mes | CHF 0 (SEPA) |
| Yuh | CHF 0 | CHF 0 | 5 gratis/mes | CHF 0 (SEPA) |
| PostFinance | CHF 0* | CHF 0 | Ilimitadas | CHF 0 (SEPA) |
| Revolut | CHF 0 | CHF 0 | 5 gratis/mes | CHF 0 (SEPA) |
| UBS | CHF 10/mes | CHF 50/año | Ilimitadas | CHF 2 (SEPA) |
| Credit Suisse | CHF 12/mes | CHF 60/año | Ilimitadas | CHF 2 (SEPA) |

*PostFinance CHF 0 solo con e-finance (online)

---

## 📝 Cuenta Bloqueada Depósito (Sperrkonto)

**¿Qué es?**
- Cuenta especial para depósito alquiler
- Dinero bloqueado (no puedes tocarlo)
- Casero puede reclamar si daños
- Obligatorio en la mayoría alquileres

**¿Cómo abrirla?**
- En mismo banco cuenta normal
- Depositas 2-3 meses alquiler
- Generas intereses (mínimos)
- Al terminar alquiler, recuperas dinero

**Coste:**
- Neon: CHF 0
- PostFinance: CHF 20 setup
- UBS: CHF 50 setup

---

## ⚠️ Errores Comunes

❌ **Abrir cuenta antes de tener permiso residencia** → Te rechazan
❌ **Elegir UBS/Credit Suisse sin necesitarlo** → Pagas CHF 100-150/año de más
❌ **No activar TWINT** → No puedes pagar en muchos sitios
❌ **No pedir IBAN inmediatamente** → Empleador necesita para nómina
❌ **Olvidar cuenta bloqueada depósito** → Casero no firma contrato

---

## ✅ Checklist Apertura Cuenta

- [ ] Obtener permiso residencia B/L
- [ ] Obtener certificado registro comuna
- [ ] Conseguir número móvil suizo
- [ ] Descargar app Neon/Yuh
- [ ] Completar registro online
- [ ] Verificar identidad (fotos)
- [ ] Esperar aprobación 24-48h
- [ ] Activar tarjeta virtual
- [ ] Configurar TWINT
- [ ] Dar IBAN a empleador
- [ ] Abrir cuenta bloqueada depósito (si alquiler)

---

## 🔐 Seguridad

**Consejos:**
- Activa 2FA (autenticación dos factores)
- Usa Face ID/Touch ID
- Límites tarjeta online (configurar bajo)
- Notificaciones push cada pago

**Si pierdes tarjeta:**
- Bloquear desde app (inmediato)
- Pedir reposición (CHF 0-10)
- Llega en 5 días

---

## 🆘 Preguntas Frecuentes

**P: ¿Puedo abrir cuenta sin permiso residencia?**
R: No. Necesitas permiso B/L. Excepción: algunas permiten con registro comuna provisional.

**P: ¿Necesito cuenta desde día 1?**
R: No urgente día 1, pero sí en primera semana. Empleador necesita IBAN para nómina.

**P: ¿Puedo tener varias cuentas?**
R: Sí, sin límite. Recomendado: Neon (uso diario) + cuenta tradicional (backup).

**P: ¿Qué es mejor: Neon o Yuh?**
R: Neon más simple. Yuh si quieres invertir.

**P: ¿Los neobanks son seguros?**
R: Sí, regulados FinMA (autoridad suiza). Dinero protegido hasta CHF 100'000.

**P: ¿Puedo recibir nómina en Revolut extranjero?**
R: No, empleador solo paga a cuenta IBAN suizo (CH).

---

## 📱 Apps Imprescindibles

1. **Neon/Yuh** - Tu banco
2. **TWINT** - Pagos móvil
3. **SBB Mobile** - Billetes tren con TWINT
4. **Parkingpay** - Parking con TWINT

---

## 💡 Consejo Final

**Configuración recomendada:**
1. **Cuenta principal:** Neon (uso diario, gratis)
2. **Inversión:** Yuh (ahorros + acciones)
3. **Backup:** PostFinance (oficina física si la necesitas)

**Coste total:** CHF 0/mes

No necesitas banco tradicional salvo casos específicos (hipoteca, empresa).

---

**✅ Una vez abierta:**
- Comunica IBAN a empleador (email/PDF extracto)
- Configurar domiciliación seguro médico
- Dar IBAN a casero (alquiler)
- Transferir dinero desde cuenta España (Wise)

**Tiempo total:** 2-3 días todo funcionando

---

*Actualizado: Enero 2026*
*Fuente: Bancos oficiales, comparativas FinMA*
