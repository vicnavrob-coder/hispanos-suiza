# 🏥 Guía: Elegir Seguro Médico Obligatorio en Suiza

## ⚠️ OBLIGATORIO - Plazo 3 meses desde llegada

El seguro médico es **obligatorio por ley** en Suiza. Si no lo contratas en 3 meses, te asignarán uno automáticamente (y probablemente sea el más caro).

**Plazo:** 90 días desde llegada
**Multa:** Hasta CHF 2'000 + cobertura retroactiva obligatoria

---

## 🎯 Lo Básico que Debes Saber

### Sistema Suizo es Diferente:
- ✅ **Aseguradoras privadas** (no hay sistema público)
- ✅ **Cobertura básica igual en todas** (ley lo exige)
- ✅ **Pagas tú, NO el empleador** (salvo excepciones)
- ✅ **Precio varía mucho** (CHF 200-500/mes misma cobertura)

### Lo que SÍ cubre el seguro básico:
- Consultas médico cabecera
- Hospitalizaciones sala común
- Urgencias
- Maternidad
- Medicamentos lista oficial
- Rehabilitación

### Lo que NO cubre:
- ❌ Dentista (salvo accidentes)
- ❌ Gafas/lentillas (salvo niños)
- ❌ Medicina alternativa
- ❌ Habitación privada hospital

---

## 💰 Cómo Funciona el Precio

### 1. Franquicia (Franchise/Selbstbehalt)
**= Cuánto pagas TÚ antes que seguro cubra**

Opciones:
- CHF 300 (mínimo legal) → Prima más alta
- CHF 500 → Prima media
- CHF 1'000 → Prima baja
- CHF 1'500 → Prima baja
- CHF 2'000 → Prima baja
- CHF 2'500 (máximo) → Prima más baja

**Ejemplo:**
- Médico te cobra CHF 200 → Pagas CHF 200 (hasta completar franquicia)
- Luego pagas 10% hasta CHF 700 adicionales
- Después seguro cubre 100%

**¿Cuál elegir?**
- **Joven y sano:** CHF 2'500 (ahorras ~CHF 150/mes)
- **Enfermedades crónicas:** CHF 300 (pagas menos si usas mucho)

### 2. Modelo de Seguro

**a) Modelo Estándar (más caro)**
- Eliges médico libremente
- Sin restricciones
- Prima: +CHF 50-100/mes

**b) Modelo Médico Familia (recomendado)**
- Siempre vas primero a médico cabecera
- Él te deriva especialista si necesitas
- Descuento: -20% prima

**c) Modelo Telemedicina (más barato)**
- Llamas/chats antes de ir al médico
- Si es urgente, vas directamente
- Descuento: -25% prima

**d) Modelo HMO**
- Solo puedes ir a médicos de red HMO
- Descuento: -25% prima
- **Cuidado:** Red limitada, verificar cobertura ciudad

### 3. Región
- Cantones caros: Basilea, Ginebra
- Cantones baratos: Appenzell, Uri
- **Tu región la asigna el código postal**

---

## 🏆 Top 5 Aseguradoras Recomendadas

### 1. **ÖKK** ⭐⭐⭐⭐⭐
- **Precio:** Más barato (CHF 250-350/mes)
- **Modelo:** Todas opciones disponibles
- **Ventaja:** Líder precio/calidad
- **Web:** www.oekk.ch

### 2. **Swica** ⭐⭐⭐⭐
- **Precio:** Medio (CHF 300-400/mes)
- **Modelo:** Todas opciones
- **Ventaja:** Excelente servicio cliente + app
- **Web:** www.swica.ch

### 3. **CSS** ⭐⭐⭐⭐
- **Precio:** Medio (CHF 280-380/mes)
- **Modelo:** Especialistas Mymed muy buenos
- **Ventaja:** Buenos seguros complementarios
- **Web:** www.css.ch

### 4. **Helsana** ⭐⭐⭐
- **Precio:** Medio-alto (CHF 320-420/mes)
- **Modelo:** Todas opciones
- **Ventaja:** Líder mercado, red grande
- **Web:** www.helsana.ch

### 5. **Sanitas** ⭐⭐⭐
- **Precio:** Medio (CHF 300-400/mes)
- **Modelo:** Telemedicina muy buena
- **Ventaja:** App excelente
- **Web:** www.sanitas.com

---

## 🔍 Comparador Oficial: Comparis.ch

**Paso a paso:**

1. **Ve a:** https://www.comparis.ch/krankenkassen/grundversicherung
2. **Introduce:**
   - Código postal
   - Fecha nacimiento
   - Franquicia deseada
   - Modelo preferido
3. **Compara resultados**
4. **Contrata online** (tarda 5 minutos)

**Diferencia precio puede ser CHF 150/mes = CHF 1'800/año**

---

## 📋 Proceso de Contratación

### Opción 1: Online (recomendado)
1. Entra a web aseguradora o Comparis
2. Rellena formulario
3. Adjunta:
   - Copia pasaporte
   - Certificado registro comuna
4. Firma digital
5. Confirmas inicio cobertura (retroactivo desde llegada)

**Tiempo:** 10-15 minutos

### Opción 2: Teléfono
- Llama a aseguradora
- Te envían formulario por email/correo
- Rellenar y devolver firmado

### Opción 3: Presencial
- Ve a oficina (buscar en Google Maps)
- Te atienden en alemán/francés principalmente

---

## 📅 Fechas Importantes

### Inicio cobertura:
- **Retroactivo desde llegada a Suiza**
- Ejemplo: Llegas 1 enero, contratas 15 marzo → Pagas desde 1 enero

### Cambio de aseguradora:
- **Solo 1 vez al año**
- Cancelación: antes 30 noviembre
- Nuevo contrato empieza: 1 enero
- **Excepción:** Si aumentan prima >5%, puedes cancelar

---

## 💳 Formas de Pago

1. **Domiciliación bancaria** (recomendado)
   - Cargo automático mensual
   - No olvidas pagar

2. **Factura trimestral**
   - Recibes factura papel
   - Pagas en PostFinance o banco
   - Descuento 2-3% si pagas año completo

3. **Anual adelantado**
   - Descuento ~5%
   - Pero si cambias, pierdes dinero

---

## 💎 Seguros Complementarios (Opcional)

**NO obligatorios, pero útiles:**

### 1. Ambulatorio (Spitalzusatz)
- Habitación privada hospital
- Elección médico/hospital
- **Coste:** CHF 50-150/mes

### 2. Dental
- Cubre parte limpieza/ortodoncia
- **Coste:** CHF 20-40/mes
- **Cuidado:** Período carencia 6-24 meses

### 3. Medicina Alternativa
- Homeop

atía, osteopatía, acupuntura
- **Coste:** CHF 15-30/mes

### 4. Gafas/Lentillas
- CHF 200-400/año
- **Coste:** CHF 10-20/mes

**Consejo:** Contrata solo básico primer año. Año 2 evalúas si necesitas complementarios.

---

## ⚠️ Errores Comunes

❌ **No contratar en 3 meses** → Asignación automática + multa
❌ **Elegir franquicia CHF 300 siendo joven sano** → Pagas CHF 150/mes de más
❌ **No comparar precios** → Puedes pagar el doble por misma cobertura
❌ **Contratar complementarios sin leer letra pequeña** → Período carencia largo
❌ **No entender que franquicia + 10% lo pagas TÚ** → Sorpresa primera factura

---

## ✅ Checklist Contratación

- [ ] Comparar precios en Comparis.ch
- [ ] Decidir franquicia según tu salud
- [ ] Elegir modelo (Médico Familia recomendado)
- [ ] Verificar médico cabecera en red (si modelo restrictivo)
- [ ] Contratar online con documentos
- [ ] Confirmar fecha inicio retroactiva
- [ ] Configurar pago automático
- [ ] Guardar póliza y tarjeta seguro

---

## 🆘 Preguntas Frecuentes

**P: ¿El empleador paga parte del seguro?**
R: No, salvo excepciones raras. En Suiza lo pagas tú completo.

**P: ¿Puedo tener seguro español y no contratar suizo?**
R: No. Ley obliga seguro suizo. Puedes cancelar europeo.

**P: ¿Si enfermo antes de contratar, me cubre?**
R: Sí, cobertura es retroactiva desde llegada a Suiza.

**P: ¿Qué pasa si no pago?**
R: Deuda se acumula + intereses. Pueden embargar sueldo. Muy grave.

**P: ¿Puedo cambiar franquicia mid-año?**
R: No, solo al renovar (1 enero).

**P: SUVA vs seguro médico, ¿cuál es la diferencia?**
R: SUVA cubre accidentes (lo paga empleador). Seguro médico cubre enfermedades (lo pagas tú).

---

## 📱 Apps Útiles

- **Comparis** - Comparador seguros
- **App tu aseguradora** - Gestión digital
- **Medigate** - Telemedicina gratuita

---

## 💡 Consejo Final

**Configuración óptima primer año:**
- Franquicia: CHF 2'500 (si eres joven/sano)
- Modelo: Médico Familia o Telemedicina
- Aseguradora: ÖKK o Swica
- **Precio final:** CHF 220-280/mes

Año 2 evalúas según uso real.

---

**✅ Una vez contratado:**
- Guarda tarjeta seguro en cartera (la necesitas en médico/farmacia)
- Anota número póliza
- Configura app para gestión digital
- Busca médico cabecera (si modelo restrictivo)

**Tiempo total:** 30 minutos comparar + 15 minutos contratar

---

*Actualizado: Enero 2026*
*Fuente: Comparis, aseguradoras oficiales*
