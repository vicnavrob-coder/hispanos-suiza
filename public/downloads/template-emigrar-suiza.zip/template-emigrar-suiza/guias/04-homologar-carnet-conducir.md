# 🚗 Guía: Homologar Carnet de Conducir en Suiza

## ⏰ Plazo: 12 meses desde llegada

Puedes conducir con carnet español/EU hasta 12 meses. Después **obligatorio homologar**.

---

## 🎯 ¿Necesito Homologar?

### SÍ necesitas si:
- ✅ Resides permanentemente en Suiza (permiso B/L/C)
- ✅ Han pasado 12 meses desde llegada
- ✅ Conduces regularmente

### NO necesitas si:
- ❌ Solo visitas/turismo
- ❌ Tienes permiso F/N (asilo/temporal)
- ❌ Primeros 12 meses residencia

---

## 📋 Documentos Necesarios

1. **Carnet conducir original** (español/EU válido)
2. **Pasaporte/DNI** original
3. **Permiso residencia** B/L/C
4. **Certificado registro comuna** (Wohnsitzbescheinigung)
5. **Foto pasaporte** reciente (35x45mm, fondo claro)
6. **Certificado médico** (solo si +75 años o enfermedad)
7. **Formulario solicitud** (descargable o en oficina)

---

## 🔄 Proceso por Cantón

### Zürich
**Oficina:** Strassenverkehrsamt Zürich
- **Web:** www.zh.ch/fuehrerausweis
- **Teléfono:** +41 43 259 51 11
- **Dirección:** Uetlibergstrasse 301, 8036 Zürich
- **Cita:** Obligatoria online

**Proceso:**
1. Reservar cita online
2. Llevar documentos
3. Foto te la hacen allí (CHF 25)
4. Pagar tasas
5. Carnet llega en 10 días correo

### Ginebra
**Oficina:** Service des automobiles et de la navigation
- **Web:** www.ge.ch/vehicules-permis-conduire
- **Tel:** +41 22 546 96 00
- **Dirección:** Route de Veyrier 86, 1227 Carouge

### Berna
**Oficina:** Strassenverkehrs- und Schifffahrtsamt
- **Web:** www.pom.be.ch
- **Tel:** +41 31 636 41 11

### Otros cantones
- Google: "[cantón] Strassenverkehrsamt"
- Proceso similar todos cantones

---

## 💰 Costes

| Concepto | Coste |
|----------|-------|
| Tasa homologación | CHF 50-80 |
| Foto oficial | CHF 20-30 |
| Certificado médico | CHF 50-80 (si necesario) |
| **Total** | **CHF 70-150** |

---

## ⚡ ¿Necesito Examen?

### NO necesitas examen si:
- ✅ Carnet EU/EFTA/EEA
- ✅ España, Francia, Alemania, Italia, etc.

### SÍ necesitas examen si:
- ❌ Carnet América Latina (ej: Colombia, México, Argentina)
- ❌ Algunos países Asia/África

**Lista completa países sin examen:**
https://www.ch.ch/en/vehicles-and-traffic/driving-licence/

---

## 🔄 Paso a Paso (Zürich)

### 1. Reservar cita (1 semana espera)
- Web: www.zh.ch/fuehrerausweis
- Sección "Umschreibung ausl. Führerausweis"
- Elegir fecha/hora

### 2. Preparar documentos
- Originales + 1 copia cada uno
- CHF 80 efectivo o tarjeta

### 3. Ir a cita
- Llegar 10 min antes
- Control documentos
- Foto (te la hacen allí)
- Firma digital
- Pago

### 4. Entrega carnet español
- **TE LO QUITAN** (envían a España)
- Te dan **comprobante provisional**
- Válido 2 meses mientras llega suizo

### 5. Carnet suizo llega
- 7-14 días por correo
- Formato tarjeta crédito
- **Válido hasta 50 años** (luego renovar cada 10-15 años)

**Tiempo total:** 30 min en oficina

---

## 🚨 ¿Qué Pasa Si Conduces Sin Homologar?

Después de 12 meses sin homologar:
- ❌ **Multa:** CHF 200-1'000
- ❌ **Sin seguro:** Si accidente, seguro NO cubre
- ❌ **Antecedentes:** Registro policial
- ❌ **Riesgo:** Retirada coche

**No arriesgues, homologa a tiempo.**

---

## 📝 Carnet Internacional

**¿Lo necesito en Suiza?**
- ❌ No, carnet español válido 12 meses
- ✅ Útil si viajas fuera Europa (ej: USA, Canadá)

**Válido:** 3 años desde emisión
**Coste:** ~€20 en DGT España

---

## ⚠️ Categorías Especiales

### Moto (A/A1/A2)
- Misma homologación
- Sin examen adicional

### Camión/Bus (C/D)
- Necesitas certificado médico obligatorio
- Posible examen práctico

### Remolque (E)
- Homologación automática

---

## ✅ Checklist Homologación

- [ ] Verificar permiso residencia vigente
- [ ] Carnet español válido
- [ ] Reservar cita online
- [ ] Preparar documentos originales + copias
- [ ] Llevar CHF 80 efectivo/tarjeta
- [ ] Foto pasaporte (o te la hacen)
- [ ] Asistir a cita
- [ ] Entregar carnet español
- [ ] Recibir provisional
- [ ] Esperar carnet suizo (10 días)

---

## 🆘 Preguntas Frecuentes

**P: ¿Puedo recuperar mi carnet español después?**
R: No fácilmente. Suiza lo devuelve a España. Si vuelves a España, puedes pedir canje carnet suizo por español.

**P: ¿Qué pasa si pierdo carnet antes de homologar?**
R: Pide duplicado en consulado España en Suiza. Luego homologa duplicado.

**P: ¿Puedo conducir con provisional?**
R: Sí, provisional válido 2 meses. Si carnet suizo no llega, vuelve a solicitar extensión.

**P: ¿Necesito traducción jurada carnet?**
R: No, carnet EU no necesita traducción.

**P: ¿Y si paso de 12 meses sin homologar?**
R: Puedes homologar igual, pero has estado conduciendo ilegalmente (multa posible).

**P: ¿Carnet suizo sirve en España?**
R: Sí, carnet suizo válido en toda UE/EFTA.

---

## 📱 Apps Útiles

- **MySwissPass** - Pagar multas/trámites
- **Parkingpay** - Parking digital
- **TCS** - Asistencia carretera (equivalente RACE)

---

## 💡 Consejo Final

**Timeline ideal:**
- Mes 9-10: Reservar cita
- Mes 11: Homologar
- **Nunca esperar al mes 12** (oficinas lentas, posible rechazo)

**Coste total:** CHF 70-150
**Tiempo:** 30 min cita + 10 días espera

---

✅ **Una vez homologado:**
- Guardar carnet suizo en cartera
- Provisional destruir (ya no válido)
- Actualizar seguro coche si tienes

---

*Actualizado: Enero 2026*
*Fuente: Oficinas cantonales tráfico*
