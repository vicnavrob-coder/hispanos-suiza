# 🏠 Guía: Buscar Piso en Suiza

## 💰 Realidad del Mercado

**Lo primero que debes saber:**
- Alquiler = 30-40% salario neto
- Mercado muy competitivo (10-50 candidatos por piso)
- Depósito = 2-3 meses alquiler (cuenta bloqueada)
- Difícil sin permiso B/L y contrato trabajo

---

## 💸 Precios Promedio (2026)

### Zürich
- Estudio (1 hab): CHF 1'200-1'800
- 2 hab: CHF 1'800-2'500
- 3 hab: CHF 2'500-3'500

### Ginebra
- Estudio: CHF 1'100-1'700
- 2 hab: CHF 1'700-2'400
- 3 hab: CHF 2'300-3'200

### Berna
- Estudio: CHF 900-1'400
- 2 hab: CHF 1'400-2'000
- 3 hab: CHF 1'900-2'700

### Lucerna/Basilea
- Estudio: CHF 1'000-1'500
- 2 hab: CHF 1'500-2'200
- 3 hab: CHF 2'000-2'900

**Zonas rurales: -20-30%**

---

## 🔍 Portales Principales

### 1. **Homegate** ⭐⭐⭐⭐⭐
- www.homegate.ch
- Líder mercado
- Más ofertas
- Interfaz mejor

### 2. **ImmoScout24** ⭐⭐⭐⭐
- www.immoscout24.ch
- Segunda opción
- Muchas ofertas

### 3. **Comparis** ⭐⭐⭐⭐
- www.comparis.ch/immobilien
- Agregador
- Busca en varios portales

### 4. **Anibis** ⭐⭐⭐
- www.anibis.ch
- Particulares
- Más económico

### 5. **Facebook Marketplace** ⭐⭐⭐
- Sublets/WG
- Temporal
- Negociable

### 6. **Grupos Facebook** ⭐⭐⭐
- "Pisos Zürich Españoles"
- "Latinos en Suiza - Vivienda"
- "Expats Geneva Housing"

---

## 📋 Requisitos Habituales

**Lo que te pedirán:**
1. ✅ **Permiso residencia B/L**
2. ✅ **Contrato trabajo** indefinido (mejor)
3. ✅ **Certificado registro comuna**
4. ✅ **Certificado solvencia** (Betreibungsregisterauszug)
5. ✅ **3 últimas nóminas** (si llevas tiempo)
6. ✅ **Seguro responsabilidad civil** (obligatorio)
7. ✅ **Depósito 2-3 meses** (cuenta bloqueada)

**Regla oro:**
- Salario bruto ≥ 3x alquiler (mínimo)
- Ejemplo: Alquiler CHF 1'500 → Necesitas CHF 4'500/mes bruto

---

## 🔄 Proceso Búsqueda

### Fase 1: Temporal (Primeros 1-2 meses)
**Opciones:**
- Airbnb (caro pero flexible)
- Hostels long-term
- Sublets (Facebook/Airbnb)
- WG (piso compartido temporal)

**Coste:** CHF 800-1'500/mes

### Fase 2: Definitivo
1. **Buscar daily** en portales (ofertas desaparecen en 24h)
2. **Solicitar viewing** (visitas)
3. **Preparar dosier**
4. **Viewing** (15-20 min)
5. **Aplicar mismo día**
6. **Esperar decisión** (1 semana)

---

## 📄 Dosier Perfecto (Bewerbungsmappe)

**Crea PDF con:**

### Página 1: Carta presentación
```
Sehr geehrte Damen und Herren,

Mi nombre es [Nombre], trabajo en [Empresa] como [Puesto].
Busco piso en [Ciudad] porque [razón].
Salario: CHF [bruto/mes]
No fumador, sin mascotas, tranquilo.
Disponible desde [fecha].

Contacto: [email] [teléfono]

Mit freundlichen Grüssen,
[Nombre]
```

### Página 2: CV corto
- Datos personales
- Empleo actual
- Ingresos
- Referencias

### Página 3: Documentos
- Copia permiso residencia
- Copia contrato trabajo
- Certificado solvencia
- Póliza responsabilidad civil

**Tener PDF listo = ventaja competitiva**

---

## ⚡ Consejos Ganar Candidatura

### 1. Rapidez
- **Solicitar en 2h** desde publicación
- Los primeros 5-10 tienen más opciones

### 2. Email Perfecto
```
Betreff: Bewerbung Wohnung [dirección]

Guten Tag,

Ich interessiere mich für die Wohnung in [dirección].
Ich arbeite bei [empresa] als [puesto] mit einem Bruttoeinkommen von CHF [cantidad].
Ich bin Nichtraucher, keine Haustiere.

Anbei meine Bewerbungsunterlagen.
Ich freue mich auf eine Besichtigung.

Freundliche Grüsse,
[Nombre]
[Teléfono]
```

### 3. En viewing
- ✅ Llegar 5 min antes
- ✅ Vestir formal/smart casual
- ✅ Ser amable/sonreír
- ✅ Hacer preguntas inteligentes
- ✅ Llevar dosier físico
- ✅ Mencionar estabilidad laboral

### 4. Ventajas Competitivas
- Pareja sin hijos > Familia con niños
- No fumador
- Sin mascotas
- Salario alto
- Contrato indefinido
- Parecer "suizo" (conservador, tranquilo)

---

## 🏘️ Tipos Vivienda

### 1. Piso Normal
- Propio
- Más caro
- Más privacidad

### 2. WG (Wohngemeinschaft)
- Piso compartido
- -30-50% coste
- Social
- Temporal ideal

### 3. Studio
- 1 ambiente todo
- Más barato
- Ideal solteros

### 4. Apartamento
- Varios dormitorios
- Familias
- Caro

---

## 💳 Costes Iniciales

| Concepto | Coste |
|----------|-------|
| Depósito (2-3 meses) | CHF 3'000-5'000 |
| Primer mes alquiler | CHF 1'500-2'500 |
| Seguro responsabilidad | CHF 15/mes |
| Mudanza | CHF 300-800 |
| Muebles (si vacío) | CHF 2'000-5'000 |
| **Total inicial** | **CHF 7'000-15'000** |

---

## 📝 Contrato Alquiler

**Puntos verificar:**
- ✅ Duración (indefinido normal)
- ✅ Preaviso (3 meses estándar)
- ✅ Gastos incluidos (Nebenkosten: agua/calefacción)
- ✅ Qué incluye (cocina/armarios/luz)
- ✅ Cláusula aumento alquiler
- ✅ Restricciones (animales/fumar/subletting)

**Firmado = vinculante. Leer BIEN.**

---

## ⚠️ Errores Comunes

❌ **Buscar sin permiso B** → Imposible conseguir
❌ **No tener dosier listo** → Pierdes oportunidades
❌ **Escribir email en inglés** → Te ignoran
❌ **Llegar tarde a viewing** → Mala impresión
❌ **No tener depósito** → No puedes firmar
❌ **Buscar solo zona cara** → Amplía búsqueda

---

## ✅ Checklist Búsqueda

- [ ] Obtener permiso residencia B/L
- [ ] Crear dosier PDF alemán
- [ ] Certificado solvencia (Betreibungsregisterauszug)
- [ ] Contratar seguro responsabilidad civil
- [ ] Abrir cuenta bloqueada depósito
- [ ] Buscar daily en 3+ portales
- [ ] Aplicar mismo día viewing
- [ ] Preparar CHF 5'000-10'000 inicial

---

## 🆘 Preguntas Frecuentes

**P: ¿Puedo alquilar sin permiso B?**
R: Muy difícil. Algunos aceptan con registro comuna + contrato trabajo.

**P: ¿Nebenkosten qué incluye?**
R: Agua, calefacción, limpieza escalera, basuras. NO internet/luz.

**P: ¿Puedo negociar precio?**
R: Raro en ciudades. Posible en rural/pisos antiguos.

**P: ¿Cuánto tarda encontrar piso?**
R: 2 semanas-3 meses según ciudad/presupuesto. Zürich/Ginebra más difícil.

**P: ¿WG es buena opción?**
R: Sí, para empezar. Ahorras dinero, conoces gente, menos papeleo.

---

## 💡 Consejo Final

**Estrategia recomendada:**
1. **Mes 1-2:** WG/Airbnb temporal
2. **Paralelo:** Buscar definitivo con calma
3. **Aplicar 5-10 pisos/semana**
4. **Ser flexible zona** (transporte público bueno)

**No te desanimes:** Todos tardamos. Es normal 20-30 aplicaciones antes de conseguir.

---

✅ **Una vez conseguido:**
- Firmar contrato
- Transferir depósito (cuenta bloqueada)
- Alta luz/internet
- Comprar muebles básicos
- Actualizar dirección comuna (Umzug)

**Presupuesto safe:** CHF 10'000 inicial (depósito + primer mes + muebles)

---

*Actualizado: Enero 2026*
*Fuente: Homegate, ImmoScout24*
