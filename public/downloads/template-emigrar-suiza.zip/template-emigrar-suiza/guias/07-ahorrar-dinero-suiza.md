# 💸 Guía: Ahorrar Dinero en Suiza

## 🎯 Mentalidad Suiza

**Vivir en Suiza es caro, pero con smart choices ahorras 30-50%.**

Suizos son ahorradores profesionales. Aprende de ellos.

---

## 🛒 Supermercados: Diferencia CHF 400/mes

### Caros (evitar diario)
- **Coop** - Caro, calidad alta
- **Migros** - Medio-alto
- **Spar** - Caro

### Baratos (usar siempre)
- **Aldi** ⭐⭐⭐⭐⭐ - 40% más barato
- **Lidl** ⭐⭐⭐⭐⭐ - 40% más barato  
- **Denner** ⭐⭐⭐⭐ - 30% más barato
- **Action** ⭐⭐⭐⭐ - Productos hogar baratos

**Comparativa:**
| Producto | Coop | Aldi | Ahorro |
|----------|------|------|--------|
| Leche 1L | CHF 1.70 | CHF 0.95 | 44% |
| Pan | CHF 3.50 | CHF 1.45 | 59% |
| Pasta 500g | CHF 2.20 | CHF 0.79 | 64% |
| Agua 6x1.5L | CHF 3.60 | CHF 1.49 | 59% |

**Ahorro mensual:** CHF 200-400 familia

---

## 🍽️ Comer Fuera: CHF 20-40 por comida

### Caro
- Restaurantes: CHF 25-50/menú
- McDonald's: CHF 15-18/menú

### Barato
- **Comida casa:** CHF 3-5
- **Meal prep domingo:** CHF 30 → 5 comidas
- **Mensa universidad:** CHF 8-12 (si tienes acceso)
- **Kebab/Döner:** CHF 12-15 (comida completa)
- **Coop/Migros "ready to eat" 19h:** -50% descuento

**Consejo:** Llevar comida trabajo ahorra CHF 300-500/mes

---

## 🚃 Transporte: Half-Fare Card = Must

### Sin Half-Fare
- Zürich-Berna: CHF 50
- Zürich-Ginebra: CHF 84
- Zürich-Lugano: CHF 86

### Con Half-Fare (CHF 185/año)
- Zürich-Berna: CHF 25
- Zürich-Ginebra: CHF 42
- Zürich-Lugano: CHF 43

**Se paga en 2-3 viajes.** Obligatorio.

### GA Travelcard (CHF 3'860/año)
- Tren/bus ilimitado
- Solo vale si >CHF 320/mes en transporte
- Mayoría no necesitan

**Consejo:** Half-Fare + abono local (CHF 70/mes) = óptimo

---

## 📱 Móvil/Internet: Ahorra CHF 50-100/mes

### Caros (evitar)
- Swisscom: CHF 60-100/mes

### Buenos precio-calidad
- **Salt** - CHF 25-40/mes
- **Sunrise** - CHF 30-45/mes
- **Wingo** - CHF 25/mes (Swisscom low-cost)
- **Yallo** - CHF 19/mes (Sunrise low-cost)

### Internet Casa
- **Init7** - CHF 45/mes fibra ilimitada ⭐
- **Sunrise** - CHF 40-60/mes
- **Swisscom** - CHF 60-80/mes (caro)

**Configuración óptima:**
- Móvil: Yallo CHF 19
- Internet: Init7 CHF 45
- **Total:** CHF 64/mes vs CHF 150 tradicionales

**Ahorro:** CHF 86/mes = CHF 1'032/año

---

## 🏥 Seguro Médico: Ahorra CHF 2'000/año

### Estrategia
1. **Franquicia máxima** (CHF 2'500) si joven/sano
   - Ahorro: CHF 100-150/mes

2. **Modelo restrictivo** (Telemedicina/HMO)
   - Ahorro: CHF 50-100/mes

3. **Aseguradora barata** (ÖKK/Assura)
   - Ahorro: CHF 50/mes

4. **Comparar anualmente** (Comparis.ch)
   - Cancelar antes 30 noviembre

**Total ahorro:** CHF 150-250/mes = CHF 2'000-3'000/año

---

## 🏠 Vivienda: Ubicación Smart

### Zürich Ciudad: CHF 2'000
### Alrededores 20 min tren: CHF 1'400
**Ahorro:** CHF 600/mes = CHF 7'200/año

**Ciudades baratas cerca Zürich:**
- Winterthur (-30%)
- Uster (-25%)
- Baden (-20%)
- Dietikon (-25%)

**Transporte +CHF 140/mes, Ahorras CHF 460 neto**

---

## 👗 Ropa/Electrónica

### Caros
- H&M Suiza: 50% más caro que España
- Zara Suiza: 40% más caro
- Electrónica: 20-30% más cara

### Soluciones
1. **Comprar online UE** (España/Alemania)
   - Amazon.de / Amazon.es
   - Envío CHF 10-20
   - Ahorro 30-50%

2. **Segunda mano**
   - Ricardo.ch
   - Facebook Marketplace
   - Brockis (tiendas segunda mano)

3. **Black Friday** (noviembre)
   - Digitec/Galaxus descuentos reales

4. **Outlets**
   - Fox Town (Mendrisio)
   - Landquart Fashion Outlet

**Ahorro:** CHF 500-1'000/año

---

## 🍺 Ocio: Gratis o Barato

### Caro
- Cine: CHF 18-22
- Bar: CHF 8-12/cerveza
- Club entrada: CHF 20-30

### Gratis/Barato
- **Montaña:** Gratis (senderismo)
- **Lagos:** Gratis (nadar verano)
- **Museos:** Primer domingo mes gratis muchos
- **Cine:** Lunes/Martes CHF 12-15
- **Casa amigos:** Cerveza Aldi CHF 0.80

**Suiza = paraíso naturaleza gratis**

---

## 🏦 Banking/Finanzas

### Evitar
- Cajeros extranjeros: CHF 5
- Bancos tradicionales: CHF 10-15/mes
- Cambio divisa bancos: Comisión 2-4%

### Usar
- **Neon:** CHF 0/mes
- **Wise:** Transferencias internacionales
- **Revolut:** Multidivisa viajes
- **Cajeros propios:** Gratis

**Ahorro:** CHF 120-180/año

---

## 📊 Presupuesto Optimizado vs Normal

| Categoría | Normal | Optimizado | Ahorro |
|-----------|--------|------------|--------|
| Alquiler | 1'800 | 1'400 | 400 |
| Supermercado | 600 | 350 | 250 |
| Restaurantes | 300 | 80 | 220 |
| Seguro médico | 400 | 250 | 150 |
| Móvil+Internet | 150 | 64 | 86 |
| Transporte | 140 | 90 | 50 |
| Ocio | 200 | 80 | 120 |
| Ropa | 150 | 60 | 90 |
| Banking | 15 | 0 | 15 |
| **TOTAL** | **3'755** | **2'374** | **1'381** |

**Ahorro anual:** CHF 16'572

---

## 💎 Apps Ahorro

1. **Too Good To Go** - Comida restaurants -50% final día
2. **Comparis** - Comparar precios todo
3. **Aldi/Lidl** - Apps con cupones
4. **Ricardo.ch** - Segunda mano
5. **SBB Mobile** - Billetes SuperSaver (-70%)

---

## ⚠️ Trampas Caras Evitar

❌ **Comer fuera diario** - CHF 500/mes
❌ **Comprar en Coop/Migros siempre** - CHF 200/mes de más
❌ **No cambiar seguro médico anualmente** - CHF 100/mes de más
❌ **Swisscom móvil** - CHF 60/mes de más
❌ **Vivir zona premium innecesaria** - CHF 500/mes de más
❌ **No usar Half-Fare Card** - CHF 50/mes de más
❌ **Tomar café fuera** - CHF 5/día = CHF 150/mes

---

## 💡 Regla Oro Suiza

**En Suiza pagas por CONVENIENCIA.**

- Conveniencia comer fuera → +300%
- Conveniencia Coop cerca → +40%
- Conveniencia Swisscom → +60%
- Conveniencia vivir centro → +50%

**Sacrificar conveniencia = ahorrar CHF 10'000-20'000/año**

---

## ✅ Checklist Ahorro Mensual

- [ ] Comprar Aldi/Lidl/Denner
- [ ] Llevar comida trabajo
- [ ] Half-Fare Card activa
- [ ] Móvil barato (Yallo/Wingo)
- [ ] Internet barato (Init7)
- [ ] Seguro médico barato (ÖKK franquicia alta)
- [ ] Vivir fuera centro (20 min tren)
- [ ] Neobank gratis (Neon/Yuh)
- [ ] Ocio naturaleza gratis
- [ ] Pillar 3a abierto (ahorro fiscal)

---

## 🎯 Objetivos Realistas

### Año 1: Supervivencia
- Gastos: CHF 3'000-3'500/mes
- Ahorro: CHF 500-1'000/mes

### Año 2: Optimización
- Gastos: CHF 2'500-3'000/mes
- Ahorro: CHF 1'500-2'500/mes

### Año 3+: Wealth Building
- Gastos: CHF 2'300-2'800/mes
- Ahorro: CHF 2'000-4'000/mes
- Inversión: ETFs/Pillar 3a

---

## 💰 ¿Cuánto Ahorrar?

**Regla 50/30/20:**
- 50% Necesidades (alquiler, comida, seguro)
- 30% Quiero (ocio, viajes)
- 20% Ahorro (Pillar 3a, inversiones)

**Ejemplo salario CHF 6'000 neto:**
- CHF 3'000 necesidades
- CHF 1'800 quiero
- CHF 1'200 ahorro

**En 5 años:** CHF 72'000 ahorrados

---

## 🆘 Si Apretado Dinero

**Prioridades reducir:**
1. Comer fuera → CHF 0
2. Ocio caro → Naturaleza gratis
3. Ropa/compras → Freeze 3 meses
4. Transporte → Bici (gratis)
5. Vivir más lejos → Ahorro CHF 300-500

**Último recurso:** WG (piso compartido) -CHF 500-800/mes

---

## 💡 Consejo Final

**Suiza = Salarios altos, gastos controlables**

Expatriados normalmente:
- ❌ Gastan demasiado (4'000-5'000/mes)
- ❌ No comparan precios
- ❌ No optimizan seguro médico

Expatriados smart:
- ✅ Gastan 2'500-3'000/mes
- ✅ Comparan todo Comparis
- ✅ Ahorran CHF 1'000-2'000/mes

**En 3 años diferencia:** CHF 50'000 ahorrados

---

✅ **Resultado:**
Viviendo smart ahorras CHF 15'000-20'000/año más que la media sin sacrificar calidad vida.

**Mentalidad:** No se trata de ser tacaño, sino de ser inteligente.

---

*Actualizado: Enero 2026*
*Fuente: Experiencias comunidad expats*
