# 💰 Guía: Impuestos en Suiza (Básico Primer Año)

## 🎯 Sistema Suizo Simplificado

**3 niveles impuestos:**
1. **Federal** (todos Suiza igual)
2. **Cantonal** (varía mucho)
3. **Comunal** (tu ciudad)

**Total:** 10-25% salario bruto (depende cantón + salario)

---

## 💳 Retención en Nómina (Año 1)

### Si ganas <CHF 120'000/año:
**Impuesto a la fuente (Quellensteuer)**

- ✅ Descuento automático nómina
- ✅ No declaras nada
- ✅ No recibes factura sorpresa
- ✅ Retención ~10-20% según salario

**Ventaja:** Fácil, sin gestión

### Si ganas >CHF 120'000/año:
**Declaración anual obligatoria**

- ❌ NO retienen en nómina (o parcial)
- ❌ Declarar cada año
- ❌ Recibes factura en julio
- ❌ Pagas en cuotas

---

## 📊 Tabla Retención Referencia (Zürich, soltero)

| Salario Bruto/Mes | Retención % | Neto Aprox |
|-------------------|-------------|------------|
| CHF 4'000 | 8-10% | CHF 3'600 |
| CHF 5'000 | 10-12% | CHF 4'400 |
| CHF 6'000 | 11-14% | CHF 5'200 |
| CHF 7'000 | 12-15% | CHF 6'000 |
| CHF 8'000 | 13-16% | CHF 6'800 |
| CHF 10'000 | 15-18% | CHF 8'400 |

**Nota:** Varía por cantón, estado civil, hijos

---

## 🗺️ Cantones Caros vs Baratos

### Caros (alta presión fiscal)
1. **Ginebra** - Impuestos altos
2. **Vaud** - Alto
3. **Berna** - Medio-alto
4. **Basilea** - Medio-alto

### Medios
5. **Zürich** - Medio
6. **Lucerna** - Medio
7. **Argovia** - Medio

### Baratos (baja presión fiscal)
8. **Zug** - Paraíso fiscal suizo
9. **Schwyz** - Muy bajo
10. **Appenzell** - Bajo
11. **Nidwalden** - Bajo
12. **Obwalden** - Bajo

**Diferencia:** Vivir en Zug vs Ginebra = ahorrar CHF 5'000-10'000/año

---

## 🧾 Declaración Primer Año

### ¿Necesito declarar?
**NO** si:
- Salario <CHF 120'000
- Impuesto a la fuente
- Sin propiedades
- Sin otros ingresos

**SÍ** si:
- Salario >CHF 120'000
- Freelance/autónomo
- Propiedades en Suiza
- Ingresos inversiones >CHF 2'000

### Cuándo declarar:
- Recibes formulario: Enero-Marzo (año siguiente)
- Plazo entrega: 31 marzo (extensión posible)
- Pago: Julio-agosto (cuotas mensuales posible)

---

## 💎 Deducciones Importantes

### ✅ Sí Deducibles:

**1. Pillar 3a (ahorro):**
- Máximo CHF 7'056/año (2026)
- **Ahorro fiscal:** CHF 1'500-2'500 según cantón
- ¡Prácticamente gratis!

**2. Transporte trabajo:**
- Abono tren/bus 100% deducible
- Gasolina: parcial (calculado km)

**3. Comidas trabajo:**
- CHF 3'200/año (si comes fuera)

**4. Formación profesional:**
- Cursos/masters relacionados trabajo
- Hasta CHF 12'000

**5. Seguros:**
- Seguro médico 100%
- Responsabilidad civil
- Pillar 3a

**6. Gastos guardería:**
- Hasta CHF 10'000/hijo

### ❌ No Deducibles:
- Alquiler vivienda
- Ropa
- Vacaciones
- Multas tráfico

---

## 🏦 Pillar 3a - MUST HAVE

**¿Qué es?**
- Cuenta ahorro bloqueada
- Para jubilación
- Deducible impuestos

**Ventajas:**
- Ahorras CHF 7'056/año
- Reduces impuestos CHF 1'500-2'500
- Interés ~1-2%
- Recuperas a jubilación (o compra casa)

**¿Dónde abrirlo?**
- UBS/Credit Suisse: fondos inversión
- Finpension: robo-advisor (recomendado)
- Viac: ETFs bajo coste
- Frankly: PostFinance

**Coste:** CHF 0-50/año gestión

**ROI:** Inmediato (ahorro fiscal primer año)

---

## 📝 Software Declaración

### 1. **TaxMe** (recomendado)
- App móvil + web
- Guiado paso a paso
- CHF 29-49
- www.taxme.ch

### 2. **Taxfix**
- Similar TaxMe
- CHF 34.90

### 3. **Gestor fiscal**
- CHF 150-500
- Solo si complejo (empresa, propiedades)

---

## ⚠️ Errores Comunes

❌ **No abrir Pillar 3a primer año** → Pierdes CHF 1'500-2'500
❌ **No guardar recibos transporte** → No puedes deducir
❌ **Olvidar declarar criptomonedas** → Multa
❌ **No pagar factura a tiempo** → Intereses 4-5%
❌ **Pensar que en Suiza no pagas impuestos** → Sí pagas, pero menos que en otros países

---

## ✅ Checklist Impuestos Año 1

- [ ] Verificar retención en nómina cada mes
- [ ] Abrir Pillar 3a antes diciembre (deducible ese año)
- [ ] Guardar recibos: abono tren, cursos, seguros
- [ ] Si salario >CHF 120k: preparar declaración
- [ ] Si salario <CHF 120k: relajarse, impuesto automático

---

## 🆘 Preguntas Frecuentes

**P: ¿Pago impuestos en España si trabajo en Suiza?**
R: No, si resides >183 días Suiza. Pero declarar en España que resides en extranjero.

**P: ¿Cuándo recibo factura impuestos?**
R: Julio-agosto año siguiente (ej: trabajas 2026, pagas julio 2027).

**P: ¿Puedo pagar en cuotas?**
R: Sí, normalmente 3-10 cuotas mensuales sin interés.

**P: ¿Qué pasa si no declaro?**
R: Multa + interés 5% + posible denuncia.

**P: ¿Vale la pena Pillar 3a?**
R: SÍ. 100%. Ahorras ~20-30% impuestos de lo que metes.

**P: ¿IVA en Suiza?**
R: 8.1% general (incluido en precios). Tú no lo gestionas salvo autónomo.

---

## 💡 Estrategia Fiscal Óptima Año 1

### Mes 1-11:
- Guardar recibos deducibles
- Contribuir Pillar 3a mensual (CHF 588/mes)

### Diciembre:
- Maximizar Pillar 3a (si sobra dinero)
- Verificar deducciones completas

### Marzo año siguiente:
- Declarar (si >CHF 120k)
- TaxMe simplifica todo

**Ahorro fiscal año 1:** CHF 1'500-3'000 (si optimizas bien)

---

## 📱 Apps Útiles

- **TaxMe** - Declaración fácil
- **Pillar 3a app** (tu banco) - Seguimiento ahorro
- **Finpension** - Pillar 3a inversión

---

## 🔗 Links Oficiales

- **Calculadora impuestos:** https://www.ch.ch/steuern
- **Info Pillar 3a:** https://www.ch.ch/vorsorge
- **Comparador cantones:** https://www.comparis.ch/steuern

---

✅ **Recuerda:**
- Suiza impuestos bajos comparado España/Francia
- Sistema simple si <CHF 120k
- Pillar 3a = dinero gratis prácticamente
- Primer año fácil, años posteriores rutina

**Presión fiscal real:** 15-20% salario (mucho menos que España 30-40%)

---

*Actualizado: Enero 2026*
*Fuente: Administración Federal Contribuciones (AFC)*
