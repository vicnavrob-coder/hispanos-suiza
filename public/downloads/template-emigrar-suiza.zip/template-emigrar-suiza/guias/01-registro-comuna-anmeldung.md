# 📋 Guía: Registro en la Comuna (Anmeldung)

## ⚠️ CRÍTICO - OBLIGATORIO EN 14 DÍAS

El registro en la comuna (Anmeldung en alemán, Annonce d'arrivée en francés) es el **trámite más importante y urgente** al llegar a Suiza.

**Plazo:** 14 días desde tu llegada
**Consecuencia si no lo haces:** Multa de hasta CHF 1'000

---

## 🎯 ¿Qué es?

Es el registro oficial de tu domicilio en Suiza. Sin este registro NO puedes:
- Solicitar permiso de residencia
- Abrir cuenta bancaria
- Contratar seguros
- Firmar contrato alquiler definitivo
- Trabajar legalmente

---

## 📝 Documentos Necesarios

### Documentos obligatorios:
1. **Pasaporte o DNI original** (vigente)
2. **Contrato de alquiler** firmado por ambas partes
   - Si vives temporalmente: confirmación alojamiento (Airbnb, hotel, amigo)
3. **Contrato de trabajo** (si vienes a trabajar)
4. **Formulario de registro** (lo dan en la comuna o descargable online)
5. **Foto pasaporte reciente** (no siempre necesaria, pero mejor llevar 2)

### Documentos opcionales pero recomendados:
- Certificado de nacimiento apostillado
- Certificado matrimonio (si casado)
- Libro de familia (si vienes con hijos)
- Traducciones juradas al alemán/francés/italiano

---

## 🏢 ¿Dónde hacerlo?

**Busca tu comuna (Gemeinde/Commune):**

### Si vives en Zürich:
- **Kreisbüro** de tu distrito
- Buscar: "Kreisbüro [nombre tu barrio] Zürich"
- Web: https://www.stadt-zuerich.ch/kreisbueros

### Si vives en Ginebra:
- **Service de la population**
- Rue de Lausanne 64, 1202 Genève
- Tel: +41 22 546 76 00
- Web: https://www.ge.ch/demarches/arriver-geneve-s-annoncer

### Si vives en Berna:
- **Einwohnerdienste**
- Web: https://www.bern.ch/themen/einwohnerinnen-und-einwohner

### Otras ciudades:
- Google: "[tu ciudad] Einwohnerkontrolle" (alemán)
- Google: "[tu ciudad] contrôle des habitants" (francés)
- Google: "[tu ciudad] controllo abitanti" (italiano)

---

## 📅 Cómo Pedir Cita

### Opción 1: Online (más rápido)
1. Entra a la web de tu comuna
2. Busca "Termin buchen" / "Prendre rendez-vous"
3. Selecciona "Anmeldung" / "Annonce d'arrivée"
4. Elige fecha y hora
5. Confirma con email

### Opción 2: Por teléfono
- Llama a la comuna
- Di: "Ich möchte einen Termin für Anmeldung" (alemán)
- Di: "Je voudrais un rendez-vous pour l'annonce d'arrivée" (francés)

### Opción 3: Sin cita (no recomendado)
- Algunas comunas pequeñas permiten ir sin cita
- **Llegar a primera hora** (8:00-9:00)
- Espera de 1-3 horas

---

## 🔄 Proceso Paso a Paso

### 1. Llega 10 minutos antes
- Lleva TODOS los documentos originales + copias
- Ten preparado dinero/tarjeta para pagar

### 2. En la oficina
- Te entregarán formulario (si no lo descargaste)
- Rellenar datos personales, dirección, empleo

### 3. Entrega documentos
- Funcionario revisará todo
- Puede pedir documentos adicionales
- Hará copias (algunas comunas las hacen ellos)

### 4. Pago
- **Coste:** CHF 20-50 (varía por comuna)
- Aceptan efectivo y tarjeta

### 5. Recibo provisional
- Te dan **Anmeldebestätigung** (confirmación registro)
- Este documento es ORO - guárdalo bien
- Lo necesitas para TODO (banco, permiso, seguros)

### 6. Permiso de residencia (siguiente paso)
- Si eres EU/EFTA: te dan formulario solicitud permiso B
- Si no EU: debes ir a oficina cantonal migración

---

## 📄 Certificado de Registro

Tras el registro, puedes pedir **Wohnsitzbescheinigung** (certificado domicilio):
- **Coste:** CHF 10-20
- **Para qué sirve:** Abrir banco, contratar seguros, trámites
- Pedir 2-3 copias desde el primer día

---

## ⚠️ Errores Comunes a Evitar

❌ **No ir en los 14 días** → Multa garantizada
❌ **Ir sin contrato alquiler** → Te rechazan
❌ **Dar dirección temporal si tienes definitiva** → Tienes que volver a registrarte
❌ **No llevar copias** → Algunas comunas cobran CHF 2-5 por copia
❌ **No entender alemán/francés y no llevar traductor** → Pueden negarse a atenderte

---

## ✅ Checklist Pre-Cita

- [ ] Pasaporte/DNI original
- [ ] Contrato alquiler firmado
- [ ] Contrato trabajo (copia)
- [ ] Formulario rellenado (si lo descargaste)
- [ ] 2 fotos pasaporte
- [ ] Certificados apostillados (opcional pero mejor llevar)
- [ ] CHF 50 en efectivo o tarjeta
- [ ] Email confirmación cita (impreso o móvil)
- [ ] Traductor/amigo si no hablas alemán/francés

---

## 🆘 Preguntas Frecuentes

**P: ¿Puedo registrarme antes de llegar a Suiza?**
R: No, solo puedes hacerlo una vez estés físicamente en Suiza.

**P: ¿Qué pasa si vivo temporalmente en Airbnb?**
R: Puedes registrarte con dirección temporal. Cuando te mudes, debes hacer cambio de domicilio (Umzug/Déménagement).

**P: ¿Necesito traducir todo al alemán?**
R: Depende del cantón. En Zürich/Berna suelen pedir traducciones. En Ginebra aceptan francés/inglés. Mejor llevar todo traducido.

**P: ¿Me dan el permiso B el mismo día?**
R: No. El registro es paso 1. El permiso B lo tramita el cantón y tarda 2-6 semanas.

**P: ¿Puedo enviar a alguien en mi nombre?**
R: No, debes ir tú personalmente con tus documentos originales.

**P: ¿Qué pasa si estoy fuera de plazo?**
R: Ve igualmente. Te multarán pero es mejor ir tarde que no ir.

---

## 📱 Apps Útiles

- **SBB Mobile** - Para llegar en transporte público
- **Google Maps** - Ubicación exacta comuna
- **Google Translate** - Si no hablas alemán/francés

---

## 🔗 Links Oficiales por Cantón

- **Zürich:** https://www.stadt-zuerich.ch/prd/de/index/bevoelkerungsamt/umziehen.html
- **Ginebra:** https://www.ge.ch/demarches/arriver-geneve-s-annoncer
- **Berna:** https://www.be.ch/de/start/themen/bevoelkerung-ausweise-bewilligungen/einwohnerkontrolle.html
- **Basilea:** https://www.bs.ch/en/services-and-support/taxes-and-finances/arrival-departure-relocation.html
- **Lausana:** https://www.lausanne.ch/officiel/administration/securite-et-economie/service-du-controle-des-habitants.html
- **Lucerna:** https://www.stadtluzern.ch/thema/6#paragraph_19254
- **Lista todos cantones:** https://www.ch.ch/de/umzug-und-auslandaufenthalt/umziehen-in-der-schweiz/

---

**✅ Una vez completado, marca este paso y continúa con:**
1. Solicitud permiso residencia B/L
2. Contratación seguro médico obligatorio
3. Apertura cuenta bancaria

**Tiempo total estimado:** 30-60 minutos en oficina

---

*Actualizado: Enero 2026*
*Fuente: Guías oficiales cantones suizos*
